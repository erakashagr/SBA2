package com.eval.coronakit.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.eval.coronakit.entity.CoronaKit;
import com.eval.coronakit.entity.KitDetail;
import com.eval.coronakit.entity.ProductMaster;
import com.eval.coronakit.service.CoronaKitService;
import com.eval.coronakit.service.KitDetailService;
import com.eval.coronakit.service.ProductService;

@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	ProductService productService;
	
	@Autowired
	CoronaKitService coronaKitService;
	
	@Autowired
	KitDetailService kitDetailService;
	
	@RequestMapping("/home")
	public String home() {
		return "user-home";
	}
	
	@RequestMapping("/show-kit")
	public String showKit(Model model) {
		return "show-cart";
	}

	@RequestMapping("/show-list")
	public String showList(Model model) {
		List<ProductMaster> products = new ArrayList<ProductMaster>();
		products = this.productService.getAllProducts();
		model.addAttribute("products", products);
		return "show-all-item-user";
	}
	
	@RequestMapping("/add-to-cart/{productId}")
	public String showKit(@PathVariable("productId") int productId, HttpSession session) {
		ProductMaster product = productService.getProductById(productId);
		
		if (session.getAttribute("CartItems") == null) {
			List<KitDetail> cartItems = new ArrayList<KitDetail>();
			KitDetail kit = new KitDetail();
			kit.setProductId(product.getId());
			kit.setProductName(product.getProductName());
			kit.setAmount(product.getCost());
			kit.setQuantity(1);

			cartItems.add(kit);

			session.setAttribute("CartItems", cartItems);

		} else {
			@SuppressWarnings("unchecked")
			List<KitDetail> cartItems = (List<KitDetail>) session.getAttribute("CartItems");
			int index= getIndexOfItemFromCart(productId, cartItems);

			if (index == -1) {

				KitDetail kit = new KitDetail();
				kit.setProductId(product.getId());
				kit.setProductName(product.getProductName());
				kit.setAmount(product.getCost());
				kit.setQuantity(1);

				cartItems.add(kit);

			} else {

				int quantity = cartItems.get(index).getQuantity();
				//int amount = cartItems.get(index).getAmount();
				cartItems.get(index).setQuantity(quantity + 1);
				//cartItems.get(index).setAmount(amount+product.getCost());

			}

			session.setAttribute("CartItems", cartItems);
		}

		return "redirect:/user/show-list";
	}
	
	private int getIndexOfItemFromCart(int productId, List<KitDetail> cartItems) {
		for (int index = 0; index < cartItems.size(); index++) {
			if (cartItems.get(index).getProductId() == productId)
				return index;
		}
		return -1;
	}

	@RequestMapping("/checkout")
	public String checkout(Model model) {
		CoronaKit coronaKit = new CoronaKit();
		model.addAttribute("CoronaKit", coronaKit);

		return "checkout-address";
	}
	
	@RequestMapping("/finalize")
	public String finalizeOrder(@RequestParam("deliveryAddress") String address, Model model, HttpSession session) {
		@SuppressWarnings("unchecked")
		List<KitDetail> cartItems = (List<KitDetail>) session.getAttribute("CartItems");

		CoronaKit coronaKit = new CoronaKit();
		coronaKit.setDeliveryAddress(address);
		coronaKit.setOrderDate(LocalDateTime.now().toString());
		
		int total = 0;
		for (int i = 0; i < cartItems.size(); i++)
			total += cartItems.get(i).getAmount() * cartItems.get(i).getQuantity();
		
		coronaKit.setTotalAmount(total);

		coronaKit = this.coronaKitService.saveKit(coronaKit);
		
		List<KitDetail> orderedKits = new ArrayList<KitDetail>();
		for (int i = 0; i < cartItems.size(); i++) {
			KitDetail kit = cartItems.get(i);
			kit.setCoronaKitId(coronaKit.getId());
			kit.setAmount(kit.getAmount() * kit.getQuantity());
			orderedKits.add(kitDetailService.addKitItem(kit));
		}

		model.addAttribute("CoronaKit", coronaKit);
		model.addAttribute("OrderedKits", orderedKits);

		return "show-summary";
	}
	
	
	@RequestMapping("/delete/{itemId}")
	public String deleteItem(@PathVariable("itemId") int itemId, HttpSession session) {
		@SuppressWarnings("unchecked")
		List<KitDetail> cartItems = (List<KitDetail>) session.getAttribute("CartItems");

		int index = getIndexOfItemFromCart(itemId, cartItems);
		int quantity = cartItems.get(index).getQuantity();

		if (quantity > 1)
			cartItems.get(index).setQuantity(quantity - 1);
		else
			cartItems.remove(index);

		if (cartItems.isEmpty()) {
			session.setAttribute("CartItems", null);
			return "redirect:/user/show-kit";
		}

		session.setAttribute("CartItems", cartItems);

		return "redirect:/user/show-kit";
	}
}
