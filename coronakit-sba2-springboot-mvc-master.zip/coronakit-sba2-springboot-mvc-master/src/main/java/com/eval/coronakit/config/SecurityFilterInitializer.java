package com.eval.coronakit.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

// register/initialize the security filter
public class SecurityFilterInitializer 
		extends AbstractSecurityWebApplicationInitializer {

}
