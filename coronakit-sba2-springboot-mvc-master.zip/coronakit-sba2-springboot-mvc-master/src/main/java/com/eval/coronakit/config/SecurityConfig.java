package com.eval.coronakit.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.User.UserBuilder;
import org.springframework.security.config.annotation.web.builders.WebSecurity;


@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	

	@SuppressWarnings("deprecation")
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		
	
	 	UserBuilder builder =  User.withDefaultPasswordEncoder();
	 	auth.inMemoryAuthentication()
	 		.withUser(builder.username("Admin").password("admin").roles("ADMIN"))
	 		.withUser(builder.username("First").password("abc").roles("USER"))
	 		.withUser(builder.username("Second").password("abc").roles("USER"));
	} 
	
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		
		  http.authorizeRequests() .antMatchers("/").permitAll().and()
		  .authorizeRequests().antMatchers("/admin/**").hasRole("ADMIN").and()
		  .authorizeRequests().antMatchers("/user/**").hasRole("USER").and()
		  .authorizeRequests().antMatchers("/console/**").permitAll().and()
		  .formLogin()  
		  .loginPage("/custom-login")  
		  .loginProcessingUrl("/validate") 
		  .successForwardUrl("/home") .permitAll() 
		  .and()
		  .logout().permitAll() 
		  .and() .exceptionHandling() .accessDeniedPage("/custom-error");
		  http.csrf().disable(); http.headers().frameOptions().disable();
		 
		/*
		 * http.authorizeRequests() .antMatchers("/").permitAll().and()
		 * .authorizeRequests().antMatchers("/console/**").permitAll();
		 * http.authorizeRequests().antMatchers("/admin/**").hasRole("ADMIN")
		 * .antMatchers("/user/**").hasRole("USER"); http.formLogin() // form-based auth
		 * .loginPage("/custom-login") // custom login form
		 * .loginProcessingUrl("/validate") // implementation is provided free
		 * .successForwardUrl("/home").permitAll() // allow to access login form
		 * .and().logout().permitAll() // have a provision for logout (free
		 * implementation of /logout url)
		 * .and().exceptionHandling().accessDeniedPage("/custom-error");
		 * 
		 * http.csrf().disable(); http.headers().frameOptions().disable();
		 */
	}
	
	/*
	 * @Override public void configure(WebSecurity web) throws Exception { // TODO
	 * Auto-generated method stub super.configure(web); }
	 */
}

